import { Utilisateur } from './utilisateur';
import { Tag } from './tag.model';

export class UtilisateurTag {
	utilisateurID?: Utilisateur;
	tagID?: Tag;
}
