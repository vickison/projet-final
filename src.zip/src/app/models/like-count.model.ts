export class LikeCount {
    mention?: string;
    count?: number;
}
