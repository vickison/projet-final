import { Categorie } from './categorie';
import { Document } from './document.model';

export class CategorieDocument {
	categorieID?: Categorie;
	documentID?: Document;
}
