export class LikeIllustration {
    likeID?: number;
    documentID?: number;
    utilisateurIP?: string;
    mention?: string;
}
