import { Utilisateur } from './utilisateur';
import { Auteur } from './auteur.model';

export class UtilisateurAuteur {
	utilisateurID?: Utilisateur;
	auteurID?: Auteur;
}
