import { Utilisateur } from './utilisateur';
import { Categorie } from './categorie';

export class UtilisateurCategorie {
	utilisateurID?: Utilisateur;
	categorieID?: Categorie;
}
