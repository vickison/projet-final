import { Document } from './document.model';
import { Auteur } from './auteur.model';

export class AuteurDocument {
	auteurID?: Auteur;
	documentID?: Document;
}
