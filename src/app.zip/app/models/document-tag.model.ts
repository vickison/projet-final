import { Document } from './document.model';
import { Tag } from './tag.model'

export class DocumentTag {
	tagID?: Tag;
	documentID?: Document;
}
