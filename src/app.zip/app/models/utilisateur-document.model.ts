import { Utilisateur } from './utilisateur';
import { Document } from './document.model';

export class UtilisateurDocument {
	utilisateurID?: Utilisateur;
	documentID?: Document;
}
