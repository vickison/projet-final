package com.ide.api.entities;

import org.junit.Before;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AuteurTest {

    Auteur auteur;
    @Before
    public void setUp(){
        auteur = new Auteur();
    }

    @Test
    void getAuteurID() {
    }

    @Test
    void getNom() {
    }

    @Test
    void getPrenom() {
    }

    @Test
    void getEmail() {
    }
}