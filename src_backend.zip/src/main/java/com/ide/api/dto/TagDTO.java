package com.ide.api.dto;

public class TagDTO {
    private String tag;

    public TagDTO() {
    }

    public TagDTO(String tag) {
        this.tag = tag;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
