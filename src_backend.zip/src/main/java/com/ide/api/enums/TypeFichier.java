package com.ide.api.enums;

public enum TypeFichier {
    Document, Image, Audio, Vidéo
}
