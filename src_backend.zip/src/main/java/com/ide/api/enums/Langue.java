package com.ide.api.enums;

public enum Langue {
    Créole, Français, Anglais, Espanol
}
