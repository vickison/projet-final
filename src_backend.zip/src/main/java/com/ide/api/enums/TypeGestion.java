package com.ide.api.enums;

public enum TypeGestion {
    Ajouter, Modifier, Supprimer
}
