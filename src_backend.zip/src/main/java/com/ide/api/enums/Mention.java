package com.ide.api.enums;

public enum Mention {
    like, unlike
}
