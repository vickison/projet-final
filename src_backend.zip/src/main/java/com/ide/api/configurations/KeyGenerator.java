package com.ide.api.configurations;

import java.security.SecureRandom;

public class KeyGenerator {

    /*public static void main(String[] args) {
        // Generate a secure random key with 512 bits
        byte[] keyBytes = new byte[64];
        new SecureRandom().nextBytes(keyBytes);

        // Convert the byte array to a hex string
        StringBuilder keyBuilder = new StringBuilder();
        for (byte b : keyBytes) {
            keyBuilder.append(String.format("%02x", b));
        }

        // Print the generated key
        System.out.println("Generated Key: " + keyBuilder.toString());
    }*/
}

